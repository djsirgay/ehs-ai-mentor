#!/usr/bin/env python3
"""
Тест мессенджера
"""

from coffee_messenger import CoffeeMessenger
from random_coffee import RandomCoffeeManager

def test_messenger():
    print("🧪 Тестирование мессенджера...")
    
    messenger = CoffeeMessenger()
    coffee = RandomCoffeeManager()
    
    # Создаем тестовый матч
    matches = coffee.create_weekly_matches()
    if matches:
        match_id = matches[0]["id"]
        users = matches[0]["users"]
        
        print(f"📝 Матч: {match_id}")
        print(f"👥 Пользователи: {users}")
        
        # Отправляем тестовое сообщение
        msg = messenger.send_message(match_id, users[0], "Привет! Как дела?")
        print(f"📤 Отправлено: {msg}")
        
        # Получаем сообщения
        messages = messenger.get_match_messages(match_id)
        print(f"📥 Получено сообщений: {len(messages)}")
        
        for message in messages:
            print(f"  - {message['sender_id']}: {message['message']}")
    
    print("✅ Тест завершен!")

if __name__ == "__main__":
    test_messenger()