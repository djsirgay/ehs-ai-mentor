import json
from datetime import datetime
from typing import List, Dict, Optional

class CoffeeMessenger:
    def __init__(self):
        self.messages = []
        self.load_messages()
    
    def load_messages(self):
        """Загружаем сообщения из файла"""
        try:
            with open('coffee_messages.json', 'r') as f:
                self.messages = json.load(f)
        except FileNotFoundError:
            self.messages = []
    
    def save_messages(self):
        """Сохраняем сообщения в файл"""
        with open('coffee_messages.json', 'w') as f:
            json.dump(self.messages, f, indent=2)
    
    def send_message(self, match_id: str, sender_id: str, message: str, message_type: str = "text") -> Dict:
        """Отправить сообщение"""
        new_message = {
            "id": f"msg_{len(self.messages)}_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "match_id": match_id,
            "sender_id": sender_id,
            "message": message,
            "type": message_type,  # text, quick_reply, time_suggestion, system
            "timestamp": datetime.now().isoformat(),
            "read": False
        }
        
        self.messages.append(new_message)
        self.save_messages()
        return new_message
    
    def get_match_messages(self, match_id: str) -> List[Dict]:
        """Получить все сообщения для матча"""
        match_messages = [msg for msg in self.messages if msg["match_id"] == match_id]
        return sorted(match_messages, key=lambda x: x["timestamp"])
    
    def mark_as_read(self, match_id: str, user_id: str):
        """Отметить сообщения как прочитанные"""
        for msg in self.messages:
            if msg["match_id"] == match_id and msg["sender_id"] != user_id:
                msg["read"] = True
        self.save_messages()
    
    def get_unread_count(self, user_id: str) -> int:
        """Получить количество непрочитанных сообщений"""
        count = 0
        for msg in self.messages:
            if msg["sender_id"] != user_id and not msg["read"]:
                count += 1
        return count
    
    def send_system_message(self, match_id: str, message: str):
        """Отправить системное сообщение"""
        return self.send_message(match_id, "system", message, "system")
    
    def suggest_time_slots(self, match_id: str, sender_id: str, slots: List[str]):
        """Предложить временные слоты"""
        message = f"Предлагаю время встречи: {', '.join(slots)}"
        return self.send_message(match_id, sender_id, message, "time_suggestion")
    
    def confirm_meeting(self, match_id: str, time_slot: str):
        """Подтвердить встречу"""
        message = f"✅ Встреча подтверждена на {time_slot}"
        return self.send_system_message(match_id, message)