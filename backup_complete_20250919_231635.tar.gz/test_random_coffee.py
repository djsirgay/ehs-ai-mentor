#!/usr/bin/env python3
"""
Тестирование Random Coffee функциональности
"""

from random_coffee import RandomCoffeeManager
from coffee_templates import format_onboarding, get_random_icebreaker
import json

def test_random_coffee():
    print("🧪 Тестирование Random Coffee матчера...")
    
    # Создаем менеджер
    coffee = RandomCoffeeManager()
    
    # Создаем тестовые профили
    test_users = [
        {
            "user_id": "u001",
            "name": "Alice Johnson", 
            "role": "lab_tech",
            "department": "Chemistry Lab",
            "interests": ["lab-safety", "ergonomics", "learning"],
            "availability": [{"day": "weekday", "time": "morning"}]
        },
        {
            "user_id": "u002", 
            "name": "Bob Smith",
            "role": "researcher",
            "department": "Biology",
            "interests": ["environmental", "mental-health", "sports"],
            "availability": [{"day": "weekday", "time": "lunch"}]
        },
        {
            "user_id": "u003",
            "name": "Carol Davis", 
            "role": "safety_officer",
            "department": "EHS",
            "interests": ["emergency", "lab-safety", "hobbies"],
            "availability": [{"day": "weekday", "time": "afternoon"}]
        }
    ]
    
    # Создаем профили
    print("\n📝 Создание профилей...")
    for user in test_users:
        profile = coffee.create_profile(
            user_id=user["user_id"],
            name=user["name"],
            role=user["role"], 
            department=user["department"],
            interests=user["interests"],
            availability=user["availability"]
        )
        print(f"✅ Профиль создан: {profile['name']} ({profile['department']})")
    
    # Тестируем матчинг
    print("\n🎲 Создание матчей...")
    matches = coffee.create_weekly_matches()
    
    if matches:
        for match in matches:
            print(f"🎯 Матч создан: {match['id']}")
            print(f"   Участники: {match['users']}")
            print(f"   Совместимость: {match['score']}")
            print(f"   Предлагаемое время: {', '.join(match['timeslots'])}")
    else:
        print("❌ Матчи не созданы")
    
    # Тестируем шаблоны
    print(f"\n💬 Случайный icebreaker: {get_random_icebreaker()}")
    print(f"👋 Приветствие: {format_onboarding('Alice')}")
    
    # Статистика
    print(f"\n📊 Статистика: {json.dumps(coffee.get_stats(), indent=2)}")
    
    print("\n✅ Тестирование завершено!")

if __name__ == "__main__":
    test_random_coffee()