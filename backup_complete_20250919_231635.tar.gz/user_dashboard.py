from datetime import datetime, timedelta

def generate_user_dashboard_html(user_data, assignments, scheduler, course_completion=None):


    """Генерирует HTML страницу пользователя"""
    
    user = user_data["user"]
    
    # Группируем курсы по статусам
    active_courses = []
    expired_courses = []
    upcoming_deadlines = []
    
    for assignment in assignments:
        course_id = assignment.get("course_id")
        if course_id:
            is_expired = assignment.get("is_expired", False)
            assigned_date = datetime.fromisoformat(assignment["timestamp"].replace('Z', '+00:00'))
            
            # Вычисляем дедлайн
            deadline_days = assignment.get("deadline_days", 30)
            deadline_date = assigned_date + timedelta(days=deadline_days)
            days_left = (deadline_date - datetime.now()).days
            
            is_completed = assignment.get("is_completed", False)
            
            course_info = {
                "course_id": course_id,
                "assigned_date": assigned_date.strftime("%d.%m.%Y"),
                "deadline_date": deadline_date.strftime("%d.%m.%Y"),
                "days_left": days_left,
                "priority": assignment.get("priority", "normal"),
                "reason": assignment.get("reason", ""),
                "renewal_months": assignment.get("renewal_months", "N/A"),
                "is_completed": is_completed
            }
            
            if is_completed:
                # Пройденные курсы не показываем в активных
                pass
            elif is_expired:
                expired_courses.append(course_info)
            elif days_left <= 7:
                upcoming_deadlines.append(course_info)
            else:
                active_courses.append(course_info)
    
    html = f'''
<!DOCTYPE html>
<html>
<head>
    <title>Личный кабинет - {user["name"]}</title>
    <link rel="stylesheet" href="/tahoe.css">
    <style>
    :root {{
      --space-xs: clamp(0.5rem, 1vw, 0.75rem);
      --space-s: clamp(0.75rem, 2vw, 1rem);
      --space-m: clamp(1rem, 3vw, 1.5rem);
      --space-l: clamp(1.5rem, 4vw, 2rem);
      --space-xl: clamp(2rem, 6vw, 3rem);
      --space-xxl: clamp(3rem, 8vw, 4rem);
      
      --text-xs: clamp(0.875rem, 2vw, 1rem);
      --text-s: clamp(1rem, 2.5vw, 1.125rem);
      --text-m: clamp(1.125rem, 3vw, 1.25rem);
      --text-l: clamp(1.5rem, 4vw, 2rem);
      --text-xl: clamp(2rem, 6vw, 3rem);
      --text-xxl: clamp(3rem, 8vw, 4rem);
      
      --gray-50: #fafafa;
      --gray-100: #f5f5f5;
      --gray-200: #e5e5e5;
      --gray-300: #d4d4d4;
      --gray-400: #a3a3a3;
      --gray-500: #737373;
      --gray-600: #525252;
      --gray-700: #404040;
      --gray-800: #262626;
      --gray-900: #171717;
      
      --container-max: 1200px;
      --container-pad: 20px;
      
      --bg: linear-gradient(135deg, #e0f2fe 0%, #f0f9ff 50%, #ecfdf5 100%);
      --panel: #ffffff;
      --ink: var(--gray-800);
      --muted: var(--gray-600);
      --brand: #0e7a4e;
      --brand-light: #16a34a;
      --brand-dark: #0d5f3c;
      --accent: #3b82f6;
      --success: #10b981;
      --warning: #f59e0b;
      --error: #ef4444;
      --blue: #3b82f6;
      --purple: #8b5cf6;
      --orange: #f97316;
      --red: #ef4444;
      --shadow-1: 0 3px 10px rgba(0,0,0,.08);
      --shadow-2: 0 8px 24px rgba(0,0,0,.12);
      --speed: .2s;
    }}

    * {{
      box-sizing: border-box;
    }}

    body {{
      margin: 0;
      font-family: system-ui, -apple-system, sans-serif;
      font-size: var(--text-s);
      line-height: 1.6;
      color: var(--gray-800);
      background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 50%, #86efac 100%);
      min-height: 100vh;
      padding: var(--space-m);
    }}

    .container {{
      max-width: var(--container-max);
      margin: 0 auto;
      padding: 0 var(--container-pad);
    }}
    
    .hero{{
      background: rgba(255, 255, 255, 0.25);
      backdrop-filter: blur(10px);
      border-radius: 16px;
      padding: var(--space-xl);
      margin: var(--space-l) 0;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.3);
    }}
    
    .hero h1{{
      font-size: var(--text-xl);
      font-weight: 700;
      line-height: 1.1;
      margin: 0 0 var(--space-l) 0;
      color: var(--gray-900);
    }}
    
    h1 {{
      font-size: var(--text-xxl);
      font-weight: 700;
      line-height: 1.1;
      margin: 0 0 var(--space-l) 0;
      color: var(--gray-900);
    }}

    h2 {{
      font-size: var(--text-xl);
      font-weight: 600;
      line-height: 1.2;
      margin: 0 0 var(--space-m) 0;
      color: var(--gray-900);
    }}

    h3 {{
      font-size: var(--text-l);
      font-weight: 600;
      line-height: 1.3;
      margin: 0 0 var(--space-s) 0;
      color: var(--gray-800);
    }}

    p {{
      margin: 0 0 var(--space-m) 0;
      color: var(--gray-600);
    }}
    
    button {{
      border: none;
      border-radius: 10px;
      padding: var(--space-s) var(--space-m);
      font-weight: 600;
      font-size: var(--text-xs);
      cursor: pointer;
      transition: all var(--speed);
      background: linear-gradient(135deg, var(--brand) 0%, #16a34a 100%);
      color: white;
      box-shadow: 0 4px 12px rgba(14, 122, 78, 0.3);
    }}
    
    button:hover {{
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(14, 122, 78, 0.4);
    }}
    
    button:active {{
      transform: translateY(0) scale(0.98);
    }}
    
    .tahoe-stat-card {{
      background: linear-gradient(145deg, #ffffff 0%, #f8fafc 100%);
      padding: var(--space-s);
      border-radius: 12px;
      text-align: center;
      cursor: pointer;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
      transition: all var(--speed);
      border: 1px solid rgba(255, 255, 255, 0.8);
    }}
    
    .tahoe-stat-card:hover {{
      transform: translateY(-3px) scale(1.02);
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }}
    
    .training-card {{
      background: rgba(255, 255, 255, 0.25);
      backdrop-filter: blur(10px);
      border-radius: 16px;
      padding: var(--space-xl);
      margin-bottom: var(--space-m);
      display: flex;
      align-items: center;
      gap: var(--space-m);
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      transition: all var(--speed);
      border: 1px solid rgba(255, 255, 255, 0.3);
      position: relative;
      overflow: hidden;
    }}
    
    .training-card::before {{
      content: '';
      position: absolute;
      left: 0;
      top: 0;
      bottom: 0;
      width: 4px;
      background: var(--brand);
      border-radius: 4px 0 0 4px;
    }}
    
    .training-card:hover {{
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(0,0,0,0.12);
    }}
    
    .course-item {{
      background: rgba(255, 255, 255, 0.25);
      backdrop-filter: blur(10px);
      border-radius: 16px;
      padding: var(--space-xl);
      margin-bottom: var(--space-m);
      display: flex;
      align-items: center;
      gap: var(--space-m);
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      transition: all var(--speed);
      border: 1px solid rgba(255, 255, 255, 0.3);
      position: relative;
      overflow: hidden;
    }}
    
    .course-item::before {{
      content: '';
      position: absolute;
      left: 0;
      top: 0;
      bottom: 0;
      width: 4px;
      background: var(--brand);
      border-radius: 4px 0 0 4px;
    }}
    
    .course-item:hover {{
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(0,0,0,0.12);
    }}
    
    .training-content {{
      flex: 1;
    }}
    
    .training-title {{
      margin: 0 0 var(--space-s) 0;
      display: flex;
      align-items: center;
      gap: var(--space-s);
      font-weight: 600;
      font-size: var(--text-l);
      color: var(--gray-800);
    }}
    
    .training-desc {{
      margin: 0 0 var(--space-s) 0;
      color: var(--gray-600);
      font-size: var(--text-xs);
    }}
    
    .training-meta {{
      display: flex;
      gap: var(--space-s);
      font-size: var(--text-xs);
      color: var(--gray-500);
    }}
    
    .training-btn {{
      background: var(--brand);
      color: white;
      border: none;
      padding: var(--space-xs) var(--space-s);
      border-radius: 8px;
      cursor: pointer;
      font-weight: 500;
      font-size: var(--text-xs);
      transition: all var(--speed);
    }}
    
    .training-btn:hover {{
      filter: brightness(.95);
      transform: translateY(-1px);
    }}
    
    .priority-critical::before {{ background: #dc3545; }}
    .priority-high::before {{ background: #fd7e14; }}
    .priority-normal::before {{ background: #28a745; }}
    .priority-low::before {{ background: #6c757d; }}
    
    .deadline-urgent {{ background: rgba(248, 215, 218, 0.3); }}
    .deadline-soon {{ background: rgba(255, 243, 205, 0.3); }}
    
    .status-badge {{ padding: 6px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }}
    .status-active {{ background: #d4edda; color: #155724; }}
    .status-urgent {{ background: #f8d7da; color: #721c24; }}
    .status-expired {{ background: #f5c6cb; color: #721c24; }}
    

    
    .stats {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: var(--space-m);
      margin: var(--space-l) 0;
    }}
    
    .modal {{
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.6);
      backdrop-filter: blur(8px);
      display: none;
      align-items: center;
      justify-content: center;
      z-index: 1000;
      animation: modalFadeIn 0.3s ease;
    }}
    
    .modal.show {{
      display: flex;
    }}
    
    .modal-content {{
      background: linear-gradient(135deg, #e0f2fe 0%, #f0f9ff 50%, #ecfdf5 100%);
      backdrop-filter: blur(20px);
      border-radius: 20px;
      max-width: 900px;
      width: 95%;
      max-height: 85vh;
      overflow: hidden;
      box-shadow: 0 25px 80px rgba(0,0,0,0.15), 0 0 0 1px rgba(255,255,255,0.5);
      border: 1px solid rgba(255, 255, 255, 0.8);
      animation: modalSlideIn 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
    }}
    
    .modal-header {{
      padding: var(--space-xl) var(--space-xl) var(--space-l);
      background: linear-gradient(135deg, #2a7d2e 0%, #66d36f 100%);
      color: white;
      position: relative;
      border-radius: 20px 20px 0 0;
    }}
    
    .modal-header h3 {{
      margin: 0;
      font-size: var(--text-xl);
      font-weight: 700;
      color: white;
    }}
    
    .modal-body {{
      padding: var(--space-xl);
      overflow-y: auto;
      max-height: calc(85vh - 120px);
    }}
    
    .modal-close {{
      position: absolute;
      top: 15px;
      right: 20px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.3);
      border-radius: 50%;
      width: 40px;
      height: 40px;
      font-size: 20px;
      cursor: pointer;
      color: white;
      transition: all var(--speed);
      display: flex;
      align-items: center;
      justify-content: center;
    }}
    
    .modal-close:hover {{
      background: rgba(255, 255, 255, 0.3);
      transform: scale(1.1);
    }}
    
    @keyframes modalFadeIn {{
      from {{ opacity: 0; }}
      to {{ opacity: 1; }}
    }}
    
    @keyframes modalSlideIn {{
      from {{ 
        opacity: 0;
        transform: translateY(-50px) scale(0.9);
      }}
      to {{ 
        opacity: 1;
        transform: translateY(0) scale(1);
      }}
    }}
    </style>
</head>
<body>
    <div class="container">
        <!-- Header в виде карточки -->
        <div class="hero" style="background: linear-gradient(135deg, #2a7d2e 0%, #66d36f 100%); color: white; grid-column: 1 / -1; margin-bottom: 20px;">
            <div style="display: flex; justify-content: space-between; align-items: center; gap: 16px;">
                <div style="display: flex; align-items: center; gap: 24px;">
                    <img src="/calpoly-logo.png" alt="Cal Poly" height="64" style="filter: brightness(0) invert(1);">
                    <div>
                        <div style="font-size: 28px; font-weight: 700; color: white; letter-spacing: -0.01em;">👤 Hello, <strong onclick="showUserProfile()" style="cursor: pointer; text-decoration: underline; text-decoration-style: solid; text-decoration-thickness: 1px; text-underline-offset: 4px;">{user["name"]}</strong></div>
                        <div id="motivationalStatus" onclick="openMeditation()" style="font-size: 20px; color: rgba(255, 255, 255, 0.9); margin-top: 4px; font-weight: 300; cursor: pointer; transition: opacity 0.3s ease;" onmouseover="this.style.opacity='0.7'" onmouseout="this.style.opacity='1'">✨ {user["role"]} | {user["department"]}</div>
                    </div>
                </div>
                <div style="display: flex; align-items: center; gap: 16px;">
                    <button id="coffeeButton" onclick="openAIChat()" style="background: rgba(255, 255, 255, 0.2); color: white; border: 1px solid rgba(255, 255, 255, 0.3); white-space: nowrap; position: relative;">
                        ☕ Random Coffee AI
                        <span id="messageNotification" style="display: none; position: absolute; top: -8px; right: -8px; background: #ef4444; color: white; border-radius: 50%; width: 20px; height: 20px; font-size: 12px; font-weight: bold; text-align: center; line-height: 20px;"></span>
                    </button>
                    <button onclick="window.history.back()" style="background: rgba(255, 255, 255, 0.2); color: white; border: 1px solid rgba(255, 255, 255, 0.3);">Logout</button>
                </div>
            </div>
        </div>
    
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div class="hero" style="background: rgba(255, 255, 255, 0.25); backdrop-filter: blur(10px);">
                <h1 style="font-size: 48px; font-weight: 800;">📊 System Statistics</h1>
                

                
                <!-- Прогресс бар -->
                <div style="margin: var(--space-l) 0;">
                    <div style="background: linear-gradient(145deg, #ffffff 0%, #f8fafc 100%); backdrop-filter: blur(10px); border-radius: 16px; padding: var(--space-l); border: 1px solid rgba(255, 255, 255, 0.3);">
                        <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: var(--space-s);">
                            <span style="font-weight: 600; color: var(--gray-800); font-size: var(--text-l);">Training Progress</span>
                            <span style="font-weight: 700; color: var(--brand); font-size: var(--text-l);">{round((sum(1 for a in assignments if a.get('is_completed', False)) / len(assignments) * 100) if assignments else 0)}%</span>
                        </div>
                        <div style="position: relative; height: 12px; border-radius: 999px; background: rgba(200,200,200,0.4); overflow: hidden; margin: var(--space-s) 0;">
                            <div style="height: 100%; width: {round((sum(1 for a in assignments if a.get('is_completed', False)) / len(assignments) * 100) if assignments else 0)}%; background: linear-gradient(90deg, var(--brand), var(--success)); transition: width 0.6s ease; border-radius: 999px;"></div>
                        </div>
                        <div style="display: flex; gap: var(--space-m); margin-top: var(--space-s); font-size: var(--text-xs); color: var(--gray-700);">
                            <span><strong style="color: var(--success);">{sum(1 for a in assignments if a.get('is_completed', False))}</strong> Completed</span>
                            <span><strong style="color: var(--blue);">{len(active_courses)}</strong> Active</span>
                            <span><strong style="color: var(--red);">{len(expired_courses)}</strong> Overdue</span>
                        </div>
                    </div>
                </div>
                

            </div>
            
            <!-- Правая колонка - Next Action Required -->
            <div class="hero" style="background: linear-gradient(135deg, #dc2626 0%, #ef4444 50%, #f87171 100%) !important; color: white !important; border-radius: 32px !important; box-shadow: 0 20px 40px rgba(220, 38, 38, 0.3) !important;">
                <h1 style="font-size: 46px; font-weight: 800;">🔔 Next Action Required</h1>
                
                <div id="nextActionContent" style="margin: 40px 0;">
                    <!-- Контент будет загружен через JavaScript -->
                </div>
            </div>
        </div>
    '''
    
    # Передаем реальные данные в JavaScript
    import json
    html += f'''
        <script>
            const upcoming_deadlines = {json.dumps([dict(course) for course in upcoming_deadlines])};
            const active_courses = {json.dumps([dict(course) for course in active_courses])};
        </script>
    '''
    
    # Срочные дедлайны
    if upcoming_deadlines:
        html += '''
        <div class="tahoe-card tahoe-animate">
            <h1 style="font-size: 48px; font-weight: 800;">⚠️ Срочные дедлайны (менее 7 дней)</h1>
        '''
        for course in upcoming_deadlines:
            priority_class = f"priority-{course['priority']}"
            if course['days_left'] <= 3:
                deadline_class = "deadline-urgent"
                status_badge = '<span class="status-badge status-urgent">🚨 СРОЧНО</span>'
            else:
                deadline_class = "deadline-soon"
                status_badge = '<span class="status-badge status-urgent">⚠️ СКОРО</span>'
            
            html += f'''
        <div class="course-item {priority_class} {deadline_class}">
            <div class="training-content">
                <h3 class="training-title">
                    <span>📚</span>
                    {course["course_id"]}
                </h3>
                <p class="training-desc">Назначен {course["assigned_date"]} • Дедлайн {course["deadline_date"]} ({course["days_left"]} дн.)</p>
                <div class="training-meta">
                    <span>🎯 {course["priority"]}</span>
                    <span>Status: Срочный дедлайн</span>
                </div>
                {f'<div style="margin-top: 8px; font-style: italic; color: var(--gray-600); font-size: var(--text-xs);">💡 {course["reason"]}</div>' if course["reason"] else ''}
            </div>
            <div style="display: flex; flex-direction: column; gap: 8px; align-items: flex-end;">
                {status_badge}
                <button class="tahoe-button" onclick="completeCourse('{course["course_id"]}')">
                    ✅ Завершить
                </button>
            </div>
        </div>
            '''
        html += '</div>'
    
    # Активные курсы
    if active_courses:
        html += '''
        <div class="tahoe-card tahoe-animate">
            <h1 style="font-size: 48px; font-weight: 800;">✅ Активные курсы</h1>
        '''
        for course in active_courses:
            priority_class = f"priority-{course['priority']}"
            status_badge = '<span class="status-badge status-active">✅ АКТИВЕН</span>'
            
            html += f'''
        <div class="course-item {priority_class}">
            <div class="training-content">
                <h3 class="training-title">
                    <span>📚</span>
                    {course["course_id"]}
                </h3>
                <p class="training-desc">Назначен {course["assigned_date"]} • Дедлайн {course["deadline_date"]} ({course["days_left"]} дн.)</p>
                <div class="training-meta">
                    <span>🎯 {course["priority"]}</span>
                    <span>🔄 Каждые {course["renewal_months"]} мес.</span>
                    <span>Status: Активен</span>
                </div>
                {f'<div style="margin-top: 8px; font-style: italic; color: var(--gray-600); font-size: var(--text-xs);">💡 {course["reason"]}</div>' if course["reason"] else ''}
            </div>
            <div style="display: flex; flex-direction: column; gap: 8px; align-items: flex-end;">
                {status_badge}
                <button class="tahoe-button" onclick="completeCourse('{course["course_id"]}')">
                    ✅ Завершить
                </button>
            </div>
        </div>
            '''
        html += '</div>'
    
    # Просроченные курсы
    if expired_courses:
        html += '''
        <div class="tahoe-card tahoe-animate">
            <h1 style="font-size: 48px; font-weight: 800;">❌ Просроченные курсы</h1>
        '''
        for course in expired_courses:
            priority_class = f"priority-{course['priority']}"
            status_badge = '<span class="status-badge status-expired">❌ ПРОСРОЧЕН</span>'
            
            html += f'''
        <div class="course-item {priority_class}" style="background: rgba(248, 215, 218, 0.3);">
            <div class="training-content">
                <h3 class="training-title">
                    <span>📚</span>
                    {course["course_id"]}
                </h3>
                <p class="training-desc">Назначен {course["assigned_date"]} • Просрочен на {abs(course["days_left"])} дн.</p>
                <div class="training-meta">
                    <span>🎯 {course["priority"]}</span>
                    <span>Status: Просрочен</span>
                </div>
                {f'<div style="margin-top: 8px; font-style: italic; color: var(--gray-600); font-size: var(--text-xs);">💡 {course["reason"]}</div>' if course["reason"] else ''}
            </div>
            <div style="display: flex; flex-direction: column; gap: 8px; align-items: flex-end;">
                {status_badge}
            </div>
        </div>
            '''
        html += '</div>'
    
    # Завершенные курсы
    completed_courses = [a for a in assignments if a.get('is_completed', False)]
    if completed_courses:
        html += '''
        <div class="tahoe-card tahoe-animate">
            <h1 style="font-size: 48px; font-weight: 800;">✅ Завершенные курсы</h1>
        '''
        for assignment in completed_courses:
            course_id = assignment.get("course_id")
            assigned_date = datetime.fromisoformat(assignment["timestamp"].replace('Z', '+00:00')).strftime("%d.%m.%Y")
            priority = assignment.get("priority", "normal")
            priority_class = f"priority-{priority}"
            
            # Находим дату завершения
            completion_info = None
            if course_completion:
                completion_info = next((c for c in course_completion.completions if c["user_id"] == user["user_id"] and c["course_id"] == course_id), None)
            completed_date = "N/A"
            if completion_info:
                completed_date = datetime.fromisoformat(completion_info["completed_at"]).strftime("%d.%m.%Y")
            
            html += f'''
        <div class="course-item {priority_class}" style="background: rgba(212, 237, 218, 0.3);">
            <div class="training-content">
                <h3 class="training-title">
                    <span>📚</span>
                    {course_id}
                </h3>
                <p class="training-desc">Назначен {assigned_date} • Завершен {completed_date}</p>
                <div class="training-meta">
                    <span>🎯 {priority}</span>
                    <span>Status: Завершен</span>
                </div>
                {f'<div style="margin-top: 8px; font-style: italic; color: var(--gray-600); font-size: var(--text-xs);">💡 {assignment.get("reason", "")}</div>' if assignment.get("reason") else ''}
            </div>
            <div style="display: flex; flex-direction: column; gap: 8px; align-items: flex-end;">
                <span class="status-badge" style="background: #d4edda; color: #155724;">✅ ЗАВЕРШЕН</span>
            </div>
        </div>
            '''
        html += '</div>'
    
    if not assignments:
        html += '''
        <div class="tahoe-card tahoe-animate">
            <p style="text-align: center; color: var(--gray-600); font-style: italic;">
                📚 У вас пока нет назначенных курсов
            </p>
        </div>
        '''
    
    html += '''
        <div class="tahoe-card tahoe-animate" style="text-align: center;">
            <p style="color: var(--gray-600); font-size: var(--text-xs);">
                🤖 Курсы назначаются автоматически на основе анализа протоколов безопасности<br>
                📧 При новых назначениях вы получите уведомление
            </p>
        </div>
    </div>
    
    <!-- Modal -->
    <div id="mainModal" class="modal" onclick="if(event.target === this) closeModal()">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalTitle">Title</h3>
                <button class="modal-close" onclick="closeModal()">×</button>
            </div>
            <div class="modal-body" id="modalBody">
                <!-- Content -->
            </div>
        </div>
    </div>

    <script>
        // Мотивирующие статусы для охраны труда
        const motivationalStatuses = [
            'Test completed? Time to relax and meditate! 🧘‍♀️',
            'You passed! Now breathe deeply and unwind! ✨',
            'Great job on the test! You deserve a peaceful moment! 🌸',
            'Training done? Perfect time for mindful meditation! 🕯️',
            'Test success! Reward yourself with inner peace! 🌟',
            'Finished the course? Your mind deserves rest now! 🍃',
            'Well done! Take a moment to center yourself! 🧘‍♂️',
            'Test passed! Time for some zen and tranquility! 🌊',
            'Achievement unlocked! Now unlock your inner calm! 🔓',
            'Course complete? Complete your day with meditation! 🌅'
        ];
        
        function getRandomMotivationalStatus() {
            const randomIndex = Math.floor(Math.random() * motivationalStatuses.length);
            return motivationalStatuses[randomIndex];
        }
        
        function updateMotivationalStatus() {
            const statusElement = document.getElementById('motivationalStatus');
            if (statusElement) {
                const status = getRandomMotivationalStatus();
                const parts = status.split(' ');
                const emoji = parts.pop();
                const text = parts.join(' ');
                statusElement.innerHTML = `<span style="text-decoration: underline; text-decoration-style: dashed; text-underline-offset: 4px; text-decoration-thickness: 1px;">${text}</span> ${emoji}`;
            }
        }
        
        // Modal functions
        function showModal(title, content) {
            document.getElementById('modalTitle').textContent = title;
            document.getElementById('modalBody').innerHTML = content;
            document.getElementById('mainModal').classList.add('show');
        }
        
        function closeModal() {
            document.getElementById('mainModal').classList.remove('show');
        }
        
        // Close modal on Esc key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeModal();
            }
        });
        
        function openMeditation() {
            const meditationHTML = `
                <div style="text-align: center; padding: 0;">
                    <!-- Дыхательный круг -->
                    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 20px; padding: 30px 20px; margin-bottom: 20px; position: relative; overflow: hidden;">
                        <div style="position: absolute; top: -50%; left: -50%; width: 200%; height: 200%; background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%); animation: pulse 4s ease-in-out infinite;"></div>
                        <div id="meditationTimer" style="font-size: 24px; font-weight: 200; margin: 0 0 20px 0; font-family: system-ui, -apple-system, sans-serif; color: rgba(255,255,255,0.8); letter-spacing: 0.1em; position: relative; z-index: 2;">05:00</div>
                        <div id="breathingCircle" style="width: 120px; height: 120px; border: 3px solid rgba(255,255,255,0.8); border-radius: 50%; margin: 0 auto 20px; transition: transform 4s ease-in-out; background: radial-gradient(circle, rgba(255,255,255,0.2) 0%, transparent 70%); box-shadow: 0 0 40px rgba(255,255,255,0.3), inset 0 0 30px rgba(255,255,255,0.1); position: relative; z-index: 2;"></div>
                        <div id="breathingGuide" style="font-size: 20px; opacity: 0; transition: opacity 0.5s ease; color: white; font-weight: 300; margin-bottom: 12px; position: relative; z-index: 2;">Breathe...</div>
                        <div id="affirmationText" style="font-size: 14px; opacity: 0; transition: opacity 1s ease; color: rgba(255,255,255,0.7); font-weight: 300; font-style: italic; position: relative; z-index: 2; min-height: 16px;"></div>
                    </div>
                    
                    <!-- Настройки -->
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div>
                            <div style="color: var(--gray-700); font-size: 12px; font-weight: 600; margin-bottom: 8px; text-transform: uppercase;">Duration</div>
                            <div style="display: flex; gap: 8px; justify-content: center;">
                                <button onclick="setMeditationTime(180)" style="background: #f0f9ff; color: #0369a1; border: 1px solid #bae6fd; padding: 8px 20px; border-radius: 8px; font-size: 12px; font-weight: 600; cursor: pointer;">3m</button>
                                <button onclick="setMeditationTime(300)" style="background: #f0f9ff; color: #0369a1; border: 1px solid #bae6fd; padding: 8px 20px; border-radius: 8px; font-size: 12px; font-weight: 600; cursor: pointer;">5m</button>
                                <button onclick="setMeditationTime(600)" style="background: #f0f9ff; color: #0369a1; border: 1px solid #bae6fd; padding: 8px 20px; border-radius: 8px; font-size: 12px; font-weight: 600; cursor: pointer;">10m</button>
                            </div>
                        </div>
                        <div>
                            <div style="color: var(--gray-700); font-size: 12px; font-weight: 600; margin-bottom: 8px; text-transform: uppercase;">Controls</div>
                            <div style="display: flex; gap: 8px; justify-content: center;">
                                <button onclick="startMeditation()" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; border: none; padding: 8px 20px; border-radius: 8px; cursor: pointer; font-size: 12px; font-weight: 600;">▶</button>
                                <button onclick="pauseMeditation()" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; border: none; padding: 8px 20px; border-radius: 8px; cursor: pointer; font-size: 12px; font-weight: 600;">⏸</button>
                                <button onclick="resetMeditation()" style="background: linear-gradient(135deg, #6b7280 0%, #4b5563 100%); color: white; border: none; padding: 8px 20px; border-radius: 8px; cursor: pointer; font-size: 12px; font-weight: 600;">↻</button>
                            </div>
                        </div>
                    </div>
                    
                    <div style="background: rgba(255, 255, 255, 0.4); backdrop-filter: blur(10px); border-radius: 16px; padding: 16px; margin-top: 20px; border: 2px solid rgba(255, 255, 255, 0.6); box-shadow: 0 4px 16px rgba(0,0,0,0.1); text-align: center;">
                        <div style="font-size: 14px; color: var(--gray-700); line-height: 1.4;">
                            Have you tried our low-calorie pastries at the <a href="#" style="color: var(--brand); text-decoration: underline;">cafeteria</a>?<br>
                            Get 10% off with promo code <strong style="background: rgba(14, 122, 78, 0.1); padding: 2px 6px; border-radius: 4px; color: var(--brand);">"meditation"</strong>.
                        </div>
                    </div>
                </div>
                
                <style>
                @keyframes pulse {
                    0%, 100% { transform: scale(1) rotate(0deg); opacity: 0.3; }
                    50% { transform: scale(1.1) rotate(180deg); opacity: 0.1; }
                }
                </style>
            `;
            showModal('🧘‍♀️ Mindful Meditation', meditationHTML);
        }
        

        
        function openAIChat() {
            // Сбрасываем уведомления при открытии чата
            document.getElementById('messageNotification').style.display = 'none';
            
            const coffeeChatHTML = `
                <div id="coffeeChatMessages" style="background: rgba(255, 255, 255, 0.25); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.3); border-radius: 16px; padding: 16px; margin: 16px 0; height: 400px; overflow-y: auto; font-size: 14px; box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);">
                    <div style="color: #2c3e50; text-align: center; padding: 30px 20px; font-size: 16px; line-height: 1.6;">
                        <div style="font-size: 48px; margin-bottom: 20px;">☕</div>
                        <div style="font-weight: 600; margin-bottom: 12px; color: #8b5cf6;">Random Coffee AI</div>
                        <div style="opacity: 0.8; margin-bottom: 12px;">Привет! Я помогу найти коллег для кофе-чатов</div>
                        <div style="opacity: 0.7; font-size: 14px;">Напиши "привет", "профиль" или "матчи" 🎯</div>
                    </div>
                    
                    <div id="matchesList" style="display: none; margin-top: 16px;"></div>
                    </div>
                </div>
                
                <div style="display: flex; gap: 8px; margin-top: 16px;">
                    <input type="text" id="coffeeChatInput" placeholder="Напиши что-нибудь..." style="flex: 1; padding: 12px; border: 1px solid #dee2e6; border-radius: 8px; font-size: 14px;" onkeypress="if(event.key==='Enter') sendCoffeeMessage()">
                    <button onclick="sendCoffeeMessage()" style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; font-weight: 600;">☕ Send</button>
                </div>
            `;
            showModal('☕ Random Coffee AI', coffeeChatHTML);
        }
        
        async function sendCoffeeMessage() {
            const input = document.getElementById('coffeeChatInput');
            const message = input.value.trim();
            if (!message) return;
            
            const messagesDiv = document.getElementById('coffeeChatMessages');
            
            messagesDiv.innerHTML += `<div style="margin: 8px 0; text-align: right;"><div style="background: #8b5cf6; color: white; padding: 8px 12px; border-radius: 12px; display: inline-block; max-width: 80%;">👤 ${message}</div></div>`;
            
            input.value = '';
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
            
            messagesDiv.innerHTML += `<div id="coffeeLoading" style="margin: 8px 0;"><div style="background: #e9ecef; padding: 8px 12px; border-radius: 12px; display: inline-block;">☕ Думаю...</div></div>`;
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
            
            try {
                const userId = window.location.pathname.split('/')[2];
                const formData = new FormData();
                formData.append('user_id', userId);
                formData.append('message', message);
                
                const response = await fetch('/coffee/chat', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                document.getElementById('coffeeLoading').remove();
                
                const botResponse = data.response.replace(/\\n/g, '<br>');
                messagesDiv.innerHTML += `<div style="margin: 8px 0;"><div style="background: white; border: 1px solid #dee2e6; padding: 8px 12px; border-radius: 12px; display: inline-block; max-width: 80%;">☕ ${botResponse}</div></div>`;
                messagesDiv.scrollTop = messagesDiv.scrollHeight;
                
                // Показываем матчи если пользователь спросил
                if (message.toLowerCase().includes('матч') || message.toLowerCase().includes('matches')) {
                    loadUserMatches();
                }
                
                // Обновляем счетчик сообщений
                setTimeout(checkNewMessages, 1000);
                
            } catch (error) {
                document.getElementById('coffeeLoading').remove();
                messagesDiv.innerHTML += `<div style="margin: 8px 0;"><div style="background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 8px 12px; border-radius: 12px; display: inline-block;">❌ Ошибка: ${error.message}</div></div>`;
                messagesDiv.scrollTop = messagesDiv.scrollHeight;
            }
        }
        
        // Медитация - переменные
        let meditationTimeLeft = 300;
        let meditationInterval = null;
        let meditationRunning = false;
        let breathingInterval = null;
        let currentMeditationSound = null;
        let meditationAudioContext = null;
        let currentMeditationOscillator = null;
        
        function updateMeditationDisplay() {
            const minutes = Math.floor(meditationTimeLeft / 60);
            const seconds = meditationTimeLeft % 60;
            const timerEl = document.getElementById('meditationTimer');
            if (timerEl) {
                timerEl.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }
        }
        
        function setMeditationTime(seconds) {
            if (!meditationRunning) {
                meditationTimeLeft = seconds;
                updateMeditationDisplay();
            }
        }
        
        function startMeditation() {
            if (!meditationRunning && meditationTimeLeft > 0) {
                meditationRunning = true;
                startBreathing();
                
                meditationInterval = setInterval(() => {
                    meditationTimeLeft--;
                    updateMeditationDisplay();
                    
                    if (meditationTimeLeft <= 0) {
                        pauseMeditation();
                        alert('🎉 Медитация завершена!');
                    }
                }, 1000);
            }
        }
        
        function pauseMeditation() {
            meditationRunning = false;
            if (meditationInterval) {
                clearInterval(meditationInterval);
                meditationInterval = null;
            }
            stopBreathing();
        }
        
        function resetMeditation() {
            pauseMeditation();
            meditationTimeLeft = 300;
            updateMeditationDisplay();
        }
        
        const affirmations = [
            'You are calm and centered',
            'Peace flows through you',
            'You are exactly where you need to be',
            'Your mind is clear and focused',
            'You radiate inner strength',
            'Every breath brings you peace',
            'You are worthy of rest and relaxation',
            'Your thoughts are gentle and kind',
            'You trust in your inner wisdom',
            'You are grateful for this moment'
        ];
        
        let affirmationInterval = null;
        
        function startBreathing() {
            const guide = document.getElementById('breathingGuide');
            const circle = document.getElementById('breathingCircle');
            const affirmation = document.getElementById('affirmationText');
            if (!guide || !circle) return;
            
            guide.style.opacity = '1';
            
            let breathingPhase = 0; // 0: inhale, 1: hold, 2: exhale, 3: hold
            
            breathingInterval = setInterval(() => {
                switch(breathingPhase) {
                    case 0: // Inhale
                        guide.textContent = 'Inhale...';
                        circle.style.transform = 'scale(1.5)';
                        break;
                    case 1: // Hold after inhale
                        guide.textContent = 'Hold...';
                        circle.style.transform = 'scale(1.5)';
                        break;
                    case 2: // Exhale
                        guide.textContent = 'Exhale...';
                        circle.style.transform = 'scale(1)';
                        break;
                    case 3: // Hold after exhale
                        guide.textContent = 'Hold...';
                        circle.style.transform = 'scale(1)';
                        break;
                }
                breathingPhase = (breathingPhase + 1) % 4;
            }, 3000);
            
            // Запускаем аффирмации
            if (affirmation) {
                let affirmationIndex = 0;
                affirmationInterval = setInterval(() => {
                    affirmation.style.opacity = '0';
                    setTimeout(() => {
                        affirmation.textContent = affirmations[affirmationIndex];
                        affirmation.style.opacity = '0.7';
                        affirmationIndex = (affirmationIndex + 1) % affirmations.length;
                    }, 500);
                }, 12000);
                
                // Показываем первую аффирмацию
                setTimeout(() => {
                    affirmation.textContent = affirmations[0];
                    affirmation.style.opacity = '0.7';
                }, 2000);
            }
        }
        
        function stopBreathing() {
            const guide = document.getElementById('breathingGuide');
            const circle = document.getElementById('breathingCircle');
            const affirmation = document.getElementById('affirmationText');
            
            if (guide) guide.style.opacity = '0';
            if (circle) circle.style.transform = 'scale(1)';
            if (affirmation) affirmation.style.opacity = '0';
            
            if (breathingInterval) {
                clearInterval(breathingInterval);
                breathingInterval = null;
            }
            
            if (affirmationInterval) {
                clearInterval(affirmationInterval);
                affirmationInterval = null;
            }
        }
        
        // Загружаем статистику при загрузке страницы
        async function showUserProfile() {
            showModal('👤 Профиль пользователя', '<div style="text-align: center; padding: 40px;">👤 Загружаю профиль...</div>');
            
            try {
                const userId = window.location.pathname.split('/')[2];
                const response = await fetch(`/user/${userId}`);
                const data = await response.json();
                
                if (data.error) {
                    document.getElementById('modalBody').innerHTML = `<div style="text-align: center; padding: 40px; color: var(--gray-600);">❌ ${data.error}</div>`;
                    return;
                }
                
                const completedCount = data.assignments.filter(a => a.is_completed).length;
                const expiredCount = data.assignments.filter(a => a.is_expired && !a.is_completed).length;
                const activeCount = data.assignments.filter(a => !a.is_completed && !a.is_expired).length;
                const urgentDeadlines = data.assignments.filter(a => {
                    if (a.is_completed || a.is_expired) return false;
                    const assignedDate = new Date(a.timestamp);
                    const deadlineDays = a.deadline_days || 30;
                    const deadlineDate = new Date(assignedDate.getTime() + deadlineDays * 24 * 60 * 60 * 1000);
                    const daysLeft = Math.ceil((deadlineDate - new Date()) / (1000 * 60 * 60 * 24));
                    return daysLeft <= 7 && daysLeft > 0;
                }).length;
                
                let html = '<div>';
                
                html += `<div style="background: rgba(255, 255, 255, 0.25); backdrop-filter: blur(10px); border-radius: 16px; padding: 24px; margin-bottom: 20px; border: 1px solid rgba(255, 255, 255, 0.3); box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);">`;
                html += `<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">`;
                html += `<div><h3 style="margin: 0; color: var(--gray-800); font-size: 24px;">👤 ${data.user.name}</h3><p style="margin: 4px 0 0 0; color: var(--gray-600); font-size: 14px;">${data.user.user_id}</p></div>`;
                html += `<button onclick="editProfile('${data.user.user_id}', '${data.user.name}', '${data.user.role}', '${data.user.department}')" style="background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%); color: white; padding: 8px 16px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 12px;">✏️ Редактировать</button>`;
                html += `</div>`;
                html += `<div id="profileForm" style="display: none; margin-bottom: 16px; padding: 16px; background: rgba(255,255,255,0.5); border-radius: 12px;">`;
                html += `<input type="text" id="editName" placeholder="Имя" style="width: 100%; padding: 8px; margin: 4px 0; border: 1px solid #ddd; border-radius: 6px;">`;
                html += `<input type="text" id="editRole" placeholder="Роль" style="width: 100%; padding: 8px; margin: 4px 0; border: 1px solid #ddd; border-radius: 6px;">`;
                html += `<input type="text" id="editDepartment" placeholder="Отдел" style="width: 100%; padding: 8px; margin: 4px 0; border: 1px solid #ddd; border-radius: 6px;">`;
                html += `<div style="margin-top: 12px;"><button onclick="saveProfile('${data.user.user_id}')" style="background: #10b981; color: white; padding: 8px 16px; border: none; border-radius: 6px; margin-right: 8px; cursor: pointer;">✅ Сохранить</button><button onclick="cancelEdit()" style="background: #6b7280; color: white; padding: 8px 16px; border: none; border-radius: 6px; cursor: pointer;">❌ Отмена</button></div>`;
                html += `</div>`;
                html += `<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">`;
                html += `<div><strong style="color: var(--gray-700);">🏢 Role:</strong><br><span id="roleDisplay" style="color: var(--gray-800);">${data.user.role}</span></div>`;
                html += `<div><strong style="color: var(--gray-700);">🏭 Department:</strong><br><span id="departmentDisplay" style="color: var(--gray-800);">${data.user.department}</span></div>`;
                html += `</div></div>`;
                
                html += `<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(100px, 1fr)); gap: 10px; margin: 15px 0;">`;
                html += `<div style="background: #d4edda; padding: 8px 12px; border-radius: 5px; text-align: center;"><strong>${activeCount}</strong><br><small>✅ Активных</small></div>`;
                html += `<div style="background: #cce5ff; padding: 8px 12px; border-radius: 5px; text-align: center;"><strong>${completedCount}</strong><br><small>✅ Завершено</small></div>`;
                html += `<div style="background: #ffebee; padding: 8px 12px; border-radius: 5px; text-align: center;"><strong>${urgentDeadlines}</strong><br><small>⚠️ Скоро дедлайн</small></div>`;
                html += `<div style="background: #f8d7da; padding: 8px 12px; border-radius: 5px; text-align: center;"><strong>${expiredCount}</strong><br><small>❌ Просрочено</small></div>`;
                html += `<div style="background: #e3f2fd; padding: 8px 12px; border-radius: 5px; text-align: center;"><strong>${data.total_assignments}</strong><br><small>📚 Всего</small></div>`;
                html += `</div>`;
                
                html += '</div>';
                document.getElementById('modalBody').innerHTML = html;
                
            } catch (error) {
                console.error('Error:', error);
                document.getElementById('modalBody').innerHTML = '<div style="text-align: center; padding: 40px; color: var(--gray-600);">❌ Ошибка загрузки профиля</div>';
            }
        }
        
        async function loadUserMatches() {
            try {
                const userId = window.location.pathname.split('/')[2];
                const response = await fetch(`/coffee/matches/${userId}`);
                const data = await response.json();
                
                const matchesList = document.getElementById('matchesList');
                if (data.matches && data.matches.length > 0) {
                    let html = '<div style="margin: 12px 0; padding: 12px; background: rgba(139, 92, 246, 0.1); border-radius: 12px;">';
                    html += '<h4 style="margin: 0 0 12px 0; color: #8b5cf6;">🎯 Твои матчи:</h4>';
                    
                    data.matches.slice(-3).forEach(match => {
                        const partnerId = match.users.find(id => id !== userId) || 'unknown';
                        const status = match.status === 'confirmed' ? '✅ Подтвержден' : '⏳ Ожидает';
                        
                        html += `<div style="background: white; padding: 12px; margin: 8px 0; border-radius: 8px; display: flex; justify-content: space-between; align-items: center;">`;
                        html += `<div><strong>${match.id}</strong><br><small>${status} | С ${partnerId}</small></div>`;
                        html += `<button onclick="openMatchChat('${match.id}')" style="background: #8b5cf6; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer;">💬 Чат</button>`;
                        html += `</div>`;
                    });
                    
                    html += '</div>';
                    matchesList.innerHTML = html;
                    matchesList.style.display = 'block';
                } else {
                    matchesList.style.display = 'none';
                }
            } catch (error) {
                console.error('Error loading matches:', error);
            }
        }
        
        function openMatchChat(matchId) {
            const chatHTML = `
                <div id="matchChatMessages" style="background: rgba(255, 255, 255, 0.25); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.3); border-radius: 16px; padding: 16px; margin: 16px 0; height: 300px; overflow-y: auto; font-size: 14px; box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);">
                    <div style="text-align: center; padding: 20px; color: #666;">💬 Загружаю сообщения...</div>
                </div>
                
                <div style="display: flex; gap: 8px; margin: 16px 0;">
                    <button onclick="sendQuickReply('${matchId}', 'Привет! 👋')" style="background: #10b981; color: white; border: none; padding: 6px 12px; border-radius: 6px; font-size: 12px; cursor: pointer;">👋 Привет</button>
                    <button onclick="sendQuickReply('${matchId}', 'Как насчет встречи?')" style="background: #3b82f6; color: white; border: none; padding: 6px 12px; border-radius: 6px; font-size: 12px; cursor: pointer;">☕ Встреча?</button>
                    <button onclick="sendQuickReply('${matchId}', 'Подтверждаю! ✅')" style="background: #8b5cf6; color: white; border: none; padding: 6px 12px; border-radius: 6px; font-size: 12px; cursor: pointer;">✅ ОК</button>
                </div>
                
                <div style="display: flex; gap: 8px; margin-top: 16px;">
                    <input type="text" id="matchChatInput" placeholder="Напиши сообщение..." style="flex: 1; padding: 12px; border: 1px solid #dee2e6; border-radius: 8px; font-size: 14px;" onkeypress="if(event.key==='Enter') sendMatchMessage('${matchId}')">
                    <button onclick="sendMatchMessage('${matchId}')" style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; font-weight: 600;">💬 Send</button>
                </div>
            `;
            
            showModal(`💬 Чат - ${matchId}`, chatHTML);
            loadMatchMessages(matchId);
        }
        
        async function loadMatchMessages(matchId) {
            try {
                const userId = window.location.pathname.split('/')[2];
                const response = await fetch(`/coffee/messages/${matchId}?user_id=${userId}`);
                const data = await response.json();
                
                console.log('Loading messages for match:', matchId, 'Data:', data);
                
                const messagesDiv = document.getElementById('matchChatMessages');
                if (data.success && data.messages && data.messages.length > 0) {
                    let html = '';
                    data.messages.forEach(msg => {
                        const isOwn = msg.sender_id === userId;
                        const isSystem = msg.sender_id === 'system';
                        const time = new Date(msg.timestamp).toLocaleTimeString('ru-RU', {hour: '2-digit', minute: '2-digit'});
                        
                        console.log('Message:', msg.message, 'Sender:', msg.sender_id, 'IsOwn:', isOwn);
                        
                        if (isSystem) {
                            html += `<div style="text-align: center; margin: 8px 0; padding: 8px; background: rgba(139, 92, 246, 0.1); border-radius: 8px; font-size: 12px; color: #8b5cf6;">⚙️ ${msg.message}</div>`;
                        } else {
                            const align = isOwn ? 'right' : 'left';
                            const bgColor = isOwn ? '#8b5cf6' : 'white';
                            const textColor = isOwn ? 'white' : '#333';
                            const border = isOwn ? 'none' : '1px solid #dee2e6';
                            const sender = isOwn ? 'Ты' : msg.sender_id;
                            
                            html += `<div style="margin: 8px 0; text-align: ${align};">`;
                            html += `<div style="background: ${bgColor}; color: ${textColor}; border: ${border}; padding: 8px 12px; border-radius: 12px; display: inline-block; max-width: 70%;">`;
                            html += `<strong>${sender}:</strong> ${msg.message}<br><small style="opacity: 0.7; font-size: 10px;">${time}</small>`;
                            html += `</div></div>`;
                        }
                    });
                    
                    messagesDiv.innerHTML = html;
                    messagesDiv.scrollTop = messagesDiv.scrollHeight;
                } else {
                    messagesDiv.innerHTML = '<div style="text-align: center; padding: 20px; color: #666;">💬 Начните разговор!</div>';
                }
            } catch (error) {
                console.error('Error loading messages:', error);
                document.getElementById('matchChatMessages').innerHTML = '<div style="text-align: center; padding: 20px; color: #f00;">❌ Ошибка загрузки</div>';
            }
        }
        
        async function sendMatchMessage(matchId) {
            const input = document.getElementById('matchChatInput');
            const message = input.value.trim();
            if (!message) return;
            
            try {
                const userId = window.location.pathname.split('/')[2];
                const formData = new FormData();
                formData.append('match_id', matchId);
                formData.append('sender_id', userId);
                formData.append('message', message);
                
                const response = await fetch('/coffee/send-message', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                if (data.success) {
                    input.value = '';
                    loadMatchMessages(matchId);
                }
            } catch (error) {
                console.error('Error sending message:', error);
            }
        }
        
        async function sendQuickReply(matchId, message) {
            try {
                const userId = window.location.pathname.split('/')[2];
                const formData = new FormData();
                formData.append('match_id', matchId);
                formData.append('sender_id', userId);
                formData.append('message', message);
                formData.append('message_type', 'quick_reply');
                
                const response = await fetch('/coffee/send-message', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                if (data.success) {
                    loadMatchMessages(matchId);
                }
            } catch (error) {
                console.error('Error sending quick reply:', error);
            }
        }
        
        async function checkNewMessages() {
            try {
                const userId = window.location.pathname.split('/')[2];
                const response = await fetch(`/coffee/unread/${userId}`);
                const data = await response.json();
                
                const notification = document.getElementById('messageNotification');
                if (data.success && data.unread_count > 0) {
                    notification.textContent = data.unread_count > 9 ? '9+' : data.unread_count;
                    notification.style.display = 'block';
                } else {
                    notification.style.display = 'none';
                }
                
            } catch (error) {
                console.error('Error checking messages:', error);
            }
        }
        
        window.onload = function() {
            updateMotivationalStatus();
            checkNewMessages();
            loadNextAction();
            // Проверяем новые сообщения каждые 10 секунд
            setInterval(checkNewMessages, 10000);
        }
        
        function loadNextAction() {
            const nextActionDiv = document.getElementById('nextActionContent');
            
            // Находим самый приоритетный курс из реальных данных
            let nextCourse = null;
            
            // Приоритет: срочные дедлайны > критичные > высокие > обычные
            if (upcoming_deadlines.length > 0) {
                nextCourse = upcoming_deadlines.sort((a, b) => a.days_left - b.days_left)[0];
            } else if (active_courses.length > 0) {
                const priorityOrder = {'critical': 4, 'high': 3, 'normal': 2, 'low': 1};
                nextCourse = active_courses.sort((a, b) => (priorityOrder[b.priority] || 0) - (priorityOrder[a.priority] || 0))[0];
            }
            
            if (nextCourse) {
                const isUrgent = nextCourse.days_left <= 7;
                const priorityColors = {
                    'critical': '#dc2626',
                    'high': '#ea580c', 
                    'normal': '#059669',
                    'low': '#6b7280'
                };
                
                let html = `
                    <div style="background: rgba(255, 255, 255, 0.15); backdrop-filter: blur(10px); border-radius: 20px; padding: 30px; text-align: center; border: 2px solid rgba(255, 255, 255, 0.3);">
                        <div style="font-size: 64px; margin-bottom: 20px;">${isUrgent ? '🚨' : '📚'}</div>
                        <h2 style="font-size: 24px; font-weight: 700; color: white; margin-bottom: 16px;">${nextCourse.course_id}</h2>
                        <div style="background: rgba(255, 255, 255, 0.2); padding: 12px 20px; border-radius: 12px; margin-bottom: 20px;">
                            <div style="font-size: 16px; font-weight: 600; margin-bottom: 8px;">
                                ${isUrgent ? `⏰ Дедлайн через ${nextCourse.days_left} дн.` : `📅 Назначен ${nextCourse.assigned_date}`}
                            </div>
                            <div style="font-size: 14px; opacity: 0.9;">
                                🎯 Приоритет: ${nextCourse.priority} | 🔄 Каждые ${nextCourse.renewal_months} мес.
                            </div>
                        </div>
                        ${nextCourse.reason ? `<div style="font-size: 14px; font-style: italic; opacity: 0.8; margin-bottom: 20px; line-height: 1.4;">💡 ${nextCourse.reason}</div>` : ''}
                        <button onclick="completeCourse('${nextCourse.course_id}')" style="background: rgba(255, 255, 255, 0.9); color: #dc2626; border: none; padding: 16px 32px; border-radius: 12px; font-size: 18px; font-weight: 700; cursor: pointer; transition: all 0.3s ease; box-shadow: 0 4px 12px rgba(0,0,0,0.2);" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 6px 20px rgba(0,0,0,0.3)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 12px rgba(0,0,0,0.2)'">
                            ✅ Complete Course
                        </button>
                    </div>
                `;
                
                nextActionDiv.innerHTML = html;
            } else {
                nextActionDiv.innerHTML = `
                    <div style="background: rgba(255, 255, 255, 0.15); backdrop-filter: blur(10px); border-radius: 20px; padding: 40px; text-align: center; border: 2px solid rgba(255, 255, 255, 0.3);">
                        <div style="font-size: 64px; margin-bottom: 20px;">🎉</div>
                        <h2 style="font-size: 24px; font-weight: 700; color: white; margin-bottom: 16px;">All Caught Up!</h2>
                        <div style="font-size: 16px; opacity: 0.9; line-height: 1.5;">
                            Отличная работа! У вас нет активных курсов.<br>
                            Новые курсы будут назначены автоматически.
                        </div>
                    </div>
                `;
            }
        }
        
        function editProfile(userId, name, role, department) {
            document.getElementById('profileForm').style.display = 'block';
            document.getElementById('editName').value = name;
            document.getElementById('editRole').value = role;
            document.getElementById('editDepartment').value = department;
        }
        
        function cancelEdit() {
            document.getElementById('profileForm').style.display = 'none';
        }
        
        async function saveProfile(userId) {
            const name = document.getElementById('editName').value;
            const role = document.getElementById('editRole').value;
            const department = document.getElementById('editDepartment').value;
            
            if (!name || !role || !department) {
                alert('Заполните все поля!');
                return;
            }
            
            try {
                const formData = new FormData();
                formData.append('user_id', userId);
                formData.append('name', name);
                formData.append('role', role);
                formData.append('department', department);
                
                const response = await fetch('/update-profile', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert('✅ ' + data.message);
                    document.getElementById('profileForm').style.display = 'none';
                    document.getElementById('roleDisplay').textContent = role;
                    document.getElementById('departmentDisplay').textContent = department;
                    document.querySelector('h3').innerHTML = `👤 ${name}`;
                    location.reload();
                } else {
                    alert('❌ ' + data.message);
                }
                
            } catch (error) {
                console.error('Error:', error);
                alert('❌ Ошибка сохранения');
            }
        }
        
        async function completeCourse(courseId) {
            const userId = window.location.pathname.split('/')[2];
            
            try {
                const response = await fetch('/complete-course', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `user_id=${userId}&course_id=${courseId}`
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert('✅ ' + data.message);
                    location.reload();
                } else {
                    alert('⚠️ ' + data.message);
                }
                
            } catch (error) {
                console.error('Error:', error);
                alert('❌ Ошибка при отметке курса');
            }
        }
    </script>

    <!-- Footer -->
    <footer style="background: linear-gradient(135deg, #1f2937 0%, #374151 100%); color: white; padding: 40px 0; margin-top: 60px; border-radius: 20px 20px 0 0;">
        <div class="container">
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 30px; margin-bottom: 30px;">
                <!-- AI Safety Assistant -->
                <div>
                    <h4 style="color: #f97316; margin: 0 0 15px 0; font-size: 18px; font-weight: 700;">🤖 AI Safety Assistant</h4>
                    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                        <span style="font-size: 14px; opacity: 0.9;">Powered By</span>
                        <img src="/AWS_2007_logo_white.png" alt="AWS" style="height: 28px;">
                    </div>
                </div>
                
                <!-- AI Matchmakers Team -->
                <div>
                    <h4 style="color: #3b82f6; margin: 0 0 15px 0; font-size: 18px; font-weight: 700;">👥 AI Matchmakers Team</h4>
                    <div style="font-size: 14px; line-height: 1.6; opacity: 0.9;">
                        <a href="https://www.sergey-ulyanov.pro/" target="_blank" style="color: #60a5fa; text-decoration: none; font-weight: 600;">Sergey Ulyanov</a><br>
                        <span style="opacity: 0.7;">× Visual Studio Code × Copilot × ChatGPT</span>
                    </div>
                </div>
                
                <!-- Digital Transformation Hub -->
                <div>
                    <h4 style="color: #8b5cf6; margin: 0 0 15px 0; font-size: 18px; font-weight: 700;">🚀 Digital Transformation Hub</h4>
                    <div style="font-size: 14px; line-height: 1.6; opacity: 0.9;">
                        <span style="color: #a78bfa;">DxHub × Amazon Web Services (AWS)</span><br>
                        <span style="opacity: 0.7;">August-September 2025</span>
                    </div>
                </div>
            </div>
            
            <!-- Contact Info -->
            <div style="border-top: 1px solid rgba(255,255,255,0.2); padding-top: 20px; text-align: center;">
                <div style="display: flex; justify-content: center; gap: 30px; flex-wrap: wrap; font-size: 14px; opacity: 0.8;">
                    <a href="mailto:ulyanoow@gmail.com" style="color: #60a5fa; text-decoration: none; display: flex; align-items: center; gap: 5px;">📧 ulyanoow@gmail.com</a>
                    <a href="tel:+13107137738" style="color: #60a5fa; text-decoration: none; display: flex; align-items: center; gap: 5px;">📱 (310) 713-7738</a>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
    '''
    
    return html