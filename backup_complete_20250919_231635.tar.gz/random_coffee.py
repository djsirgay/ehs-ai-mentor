import json
import random
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple

class RandomCoffeeManager:
    def __init__(self):
        self.profiles = {}
        self.matches = {}
        self.feedback = {}
        self.load_data()
    
    def load_data(self):
        """Загружаем данные из файлов"""
        try:
            with open('coffee_profiles.json', 'r') as f:
                self.profiles = json.load(f)
        except FileNotFoundError:
            self.profiles = {}
        
        try:
            with open('coffee_matches.json', 'r') as f:
                self.matches = json.load(f)
        except FileNotFoundError:
            self.matches = {}
        
        try:
            with open('coffee_feedback.json', 'r') as f:
                self.feedback = json.load(f)
        except FileNotFoundError:
            self.feedback = {}
    
    def save_data(self):
        """Сохраняем данные в файлы"""
        with open('coffee_profiles.json', 'w') as f:
            json.dump(self.profiles, f, indent=2)
        
        with open('coffee_matches.json', 'w') as f:
            json.dump(self.matches, f, indent=2)
        
        with open('coffee_feedback.json', 'w') as f:
            json.dump(self.feedback, f, indent=2)
    
    def create_profile(self, user_id: str, name: str, role: str, department: str, 
                      interests: List[str], availability: List[Dict], 
                      language: str = "en", cooldown_weeks: int = 4):
        """Создаем профиль пользователя"""
        self.profiles[user_id] = {
            "id": user_id,
            "name": name,
            "role": role,
            "department": department,
            "interests": interests,
            "availability": availability,
            "language": language,
            "cooldown_weeks": cooldown_weeks,
            "consent": True,
            "active": True,
            "created_at": datetime.now().isoformat(),
            "last_match": None,
            "total_matches": 0
        }
        self.save_data()
        return self.profiles[user_id]
    
    def update_profile(self, user_id: str, updates: Dict):
        """Обновляем профиль пользователя"""
        if user_id in self.profiles:
            self.profiles[user_id].update(updates)
            self.save_data()
            return self.profiles[user_id]
        return None
    
    def get_profile(self, user_id: str):
        """Получаем профиль пользователя"""
        return self.profiles.get(user_id)
    
    def calculate_match_score(self, user1_id: str, user2_id: str) -> int:
        """Вычисляем совместимость двух пользователей"""
        user1 = self.profiles[user1_id]
        user2 = self.profiles[user2_id]
        
        score = 0
        
        # +30: совпадение интересов
        common_interests = set(user1["interests"]) & set(user2["interests"])
        if len(common_interests) >= 1:
            score += 30
        
        # +20: разные департаменты (кросс-силос)
        if user1["department"] != user2["department"]:
            score += 20
        
        # +15: совместимое время (упрощенно)
        if self.has_compatible_time(user1["availability"], user2["availability"]):
            score += 15
        
        # +10: одинаковый язык
        if user1["language"] == user2["language"]:
            score += 10
        
        # -25: был матч недавно
        if self.had_recent_match(user1_id, user2_id):
            score -= 25
        
        # -100: запретные пары (иерархия)
        if self.is_forbidden_pair(user1, user2):
            score -= 100
        
        return max(0, score)
    
    def has_compatible_time(self, avail1: List[Dict], avail2: List[Dict]) -> bool:
        """Проверяем совместимость времени (упрощенно)"""
        days1 = {slot["day"] for slot in avail1}
        days2 = {slot["day"] for slot in avail2}
        return len(days1 & days2) > 0
    
    def had_recent_match(self, user1_id: str, user2_id: str) -> bool:
        """Проверяем, был ли недавний матч"""
        cutoff_date = datetime.now() - timedelta(weeks=4)
        
        for match in self.matches.values():
            if set([user1_id, user2_id]).issubset(set(match["users"])):
                match_date = datetime.fromisoformat(match["created_at"])
                if match_date > cutoff_date:
                    return True
        return False
    
    def is_forbidden_pair(self, user1: Dict, user2: Dict) -> bool:
        """Проверяем запретные пары (упрощенно)"""
        # Не матчим одинаковые роли в одном департаменте (может быть иерархия)
        if (user1["role"] == user2["role"] and 
            user1["department"] == user2["department"]):
            return True
        return False
    
    def create_weekly_matches(self) -> List[Dict]:
        """Создаем матчи на неделю"""
        # Получаем активных пользователей
        active_users = [uid for uid, profile in self.profiles.items() 
                       if profile.get("active", False) and profile.get("consent", False)]
        
        if len(active_users) < 2:
            return []
        
        matches = []
        used_users = set()
        
        # Простой жадный алгоритм
        for user1_id in active_users:
            if user1_id in used_users:
                continue
            
            best_match = None
            best_score = 0
            
            for user2_id in active_users:
                if user2_id == user1_id or user2_id in used_users:
                    continue
                
                score = self.calculate_match_score(user1_id, user2_id)
                if score > best_score:
                    best_score = score
                    best_match = user2_id
            
            if best_match and best_score > 20:  # Минимальный порог
                match_id = f"match_{datetime.now().strftime('%Y%m%d')}_{len(matches)}"
                match = {
                    "id": match_id,
                    "week": datetime.now().strftime("%Y-%m-%d"),
                    "users": [user1_id, best_match],
                    "score": best_score,
                    "status": "proposed",
                    "created_at": datetime.now().isoformat(),
                    "timeslots": self.suggest_timeslots(user1_id, best_match)
                }
                
                matches.append(match)
                self.matches[match_id] = match
                used_users.add(user1_id)
                used_users.add(best_match)
        
        self.save_data()
        return matches
    
    def suggest_timeslots(self, user1_id: str, user2_id: str) -> List[str]:
        """Предлагаем временные слоты"""
        # Упрощенная логика - возвращаем стандартные слоты
        return [
            "Tue 11:30-11:50",
            "Wed 15:00-15:20",
            "Thu 14:00-14:20"
        ]
    
    def confirm_match(self, match_id: str, timeslot: str):
        """Подтверждаем матч"""
        if match_id in self.matches:
            self.matches[match_id]["status"] = "confirmed"
            self.matches[match_id]["confirmed_timeslot"] = timeslot
            self.matches[match_id]["confirmed_at"] = datetime.now().isoformat()
            
            # Обновляем статистику пользователей
            for user_id in self.matches[match_id]["users"]:
                if user_id in self.profiles:
                    self.profiles[user_id]["last_match"] = datetime.now().isoformat()
                    self.profiles[user_id]["total_matches"] += 1
            
            self.save_data()
            return True
        return False
    
    def add_feedback(self, match_id: str, user_id: str, rating: int, 
                    safety_discussed: bool = False, tags: List[str] = None):
        """Добавляем обратную связь"""
        feedback_id = f"{match_id}_{user_id}"
        self.feedback[feedback_id] = {
            "match_id": match_id,
            "user_id": user_id,
            "rating": rating,
            "safety_discussed": safety_discussed,
            "tags": tags or [],
            "created_at": datetime.now().isoformat()
        }
        self.save_data()
    
    def get_user_matches(self, user_id: str) -> List[Dict]:
        """Получаем матчи пользователя"""
        user_matches = []
        for match in self.matches.values():
            if user_id in match["users"]:
                user_matches.append(match)
        
        # Сортируем по дате
        user_matches.sort(key=lambda x: x["created_at"], reverse=True)
        return user_matches
    
    def get_stats(self) -> Dict:
        """Получаем статистику"""
        total_users = len(self.profiles)
        active_users = len([p for p in self.profiles.values() if p.get("active", False)])
        total_matches = len(self.matches)
        confirmed_matches = len([m for m in self.matches.values() if m["status"] == "confirmed"])
        
        # Популярные интересы
        all_interests = []
        for profile in self.profiles.values():
            all_interests.extend(profile.get("interests", []))
        
        interest_counts = {}
        for interest in all_interests:
            interest_counts[interest] = interest_counts.get(interest, 0) + 1
        
        popular_interests = sorted(interest_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        
        return {
            "total_users": total_users,
            "active_users": active_users,
            "total_matches": total_matches,
            "confirmed_matches": confirmed_matches,
            "popular_interests": popular_interests
        }