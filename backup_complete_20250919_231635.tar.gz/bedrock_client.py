import boto3
import json
import os

class BedrockClient:
    def __init__(self):
        self.client = boto3.client(
            'bedrock-runtime',
            aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID', 'AKIAQ3YWPPO7AMOFSEF5'),
            aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY', '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'),
            region_name=os.getenv('AWS_REGION', 'us-east-1')
        )
        self.model_id = os.getenv('BEDROCK_MODEL_ID', 'us.anthropic.claude-3-5-haiku-20241022-v1:0')
    
    def chat(self, message: str, system_prompt: str = "") -> str:
        try:
            response = self.client.invoke_model(
                modelId=self.model_id,
                body=json.dumps({
                    "anthropic_version": "bedrock-2023-05-31",
                    "max_tokens": 500,
                    "temperature": 0.7,
                    "system": system_prompt,
                    "messages": [{"role": "user", "content": message}]
                })
            )
            
            result = json.loads(response['body'].read())
            return result['content'][0]['text']
            
        except Exception as e:
            return f"☕ Привет! Я Random Coffee AI. Помогу найти коллег для встреч. Ошибка: {str(e)[:50]}..."